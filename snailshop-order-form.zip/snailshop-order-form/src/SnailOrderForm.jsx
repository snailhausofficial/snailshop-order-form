import { useState } from 'react'

/* ================= ตัวแยกข้อความอัตโนมัติ ================= */
function extractPhones(s) {
  const found = []
  const re = /0[\d\-\s]{7,13}/g
  let m
  while ((m = re.exec(s))) {
    const d = m[0].replace(/\D/g, '')
    if (d.length >= 9 && d.length <= 10) found.push(d)
  }
  return [...new Set(found)]
}

export function parseMessage(raw) {
  const text = raw.replace(/\r/g, '')
  const lines = text.split('\n').map((l) => l.trim())
  const o = { tiktok: '', qty: '', type: '', date: '', name: '', phone: '', addr: '', note: '-' }

  // ชื่อ TikTok — หลัง "แอค..." + :
  let m = text.match(/แอค[^\n:：]*[:：]\s*(.+)/)
  if (m) o.tiktok = m[1].trim()

  // จำนวน + หมายเหตุ — จากบรรทัด "สถานะ / ...ชุด..."
  let statusLine = lines.find((l) => /ชุด/.test(l)) || lines.find((l) => /สถานะ/.test(l)) || ''
  let qm = statusLine.match(/(\d+)\s*ชุด/)
  if (qm) o.qty = qm[1]
  else {
    let n = statusLine.replace(/สถานะ/, '').match(/(\d+)/)
    if (n) o.qty = n[1]
  }
  let noteRaw = statusLine.replace(/สถานะ/, '').replace(/[:：]/, '').replace(/\d+\s*ชุด/, '')
  let parts = noteRaw
    .split(/[+]/)
    .map((s) => s.trim())
    .filter((s) => s && !/^รส\.?$/.test(s) && !/รวมส่ง/.test(s))
  o.note = parts.length ? parts.join(', ') : '-'

  // วันที่ส่ง
  let dateLine = lines.find((l) => /(ส่ง.*วันที่|วันที่ส่ง|วันส่ง|ส่งของ)/.test(l)) || ''
  let dm = dateLine.match(/(\d{1,2})\s*\/\s*(\d{1,2})/)
  if (dm) o.date = dm[1] + '/' + dm[2]

  // ที่อยู่ — ทุกอย่างหลัง "ที่อยู่"
  let am = text.match(/ที่อยู่\s*[:：]?\s*([\s\S]+)/)
  let addrText = am ? am[1] : ''
  o.addr = addrText.replace(/\n+/g, ' ').replace(/\s{2,}/g, ' ').trim()

  // ชื่อ + เบอร์ — จากบล็อกก่อน "ที่อยู่" ที่ไม่ใช่บรรทัดสรุป
  let beforeText = am ? text.slice(0, text.indexOf(am[0])) : text
  let beforeLines = beforeText.split('\n').map((l) => l.trim())
  const skip = /ขอบคุณ|แอค|สถานะ|ส่งของ|วันที่ส่ง|^วันส่ง|ยอด|โอน|^$/
  let candidates = beforeLines.filter((l) => l && !skip.test(l))

  let phones = extractPhones(candidates.join(' '))
  o.phone = phones.join(' / ')

  // ชื่อผู้รับ: 1) บรรทัดที่มีคำว่า "ชื่อ"  2) บรรทัดที่มีเบอร์ (ตัดเบอร์ออก)  3) บรรทัดที่ไม่มีเบอร์
  let nameLine = candidates.find((l) => /ชื่อ/.test(l))
  if (!nameLine) {
    let pl = candidates.find((l) => extractPhones(l).length > 0) || ''
    let stripped = pl.replace(/0[\d\-\s]{7,13}/g, '').replace(/\s*\/\s*/g, ' ').trim()
    nameLine = stripped || candidates.find((l) => extractPhones(l).length === 0) || ''
  }
  o.name = nameLine
    .replace(/0[\d\-\s]{7,13}/g, '')
    .replace(/ชื่อ|ผู้รับ|[:：]/g, '')
    .replace(/\s*\/\s*/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim()

  return o
}
/* ========================================================= */

const BLANK = { tiktok: '', qty: 1, type: '', date: '', name: '', phone: '', addr: '', note: '' }

export default function SnailOrderForm() {
  const [orders, setOrders] = useState([])
  const [form, setForm] = useState({ ...BLANK })
  const [paste, setPaste] = useState('')
  const [flash, setFlash] = useState({ msg: '', ok: true })

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value })

  function fillFromPaste() {
    if (!paste.trim()) {
      setFlash({ msg: 'ยังไม่มีข้อความให้แยก วางข้อความก่อนนะคะ', ok: false })
      return
    }
    const o = parseMessage(paste)
    setForm({
      tiktok: o.tiktok,
      qty: o.qty || 1,
      type: o.type,
      date: o.date,
      name: o.name,
      phone: o.phone,
      addr: o.addr,
      note: o.note === '-' ? '' : o.note,
    })
    setFlash({ msg: '✅ แยกข้อมูลแล้ว — เช็กความถูกต้องแล้วกด “เพิ่มลงตาราง”', ok: true })
  }

  function addOrder() {
    const tiktok = form.tiktok.trim()
    const name = form.name.trim()
    if (!tiktok && !name) {
      alert('ใส่ชื่อ TikTok หรือชื่อผู้รับอย่างน้อย 1 อย่างนะคะ 🐌')
      return
    }
    const o = {
      tiktok,
      qty: parseInt(form.qty) || 1,
      type: form.type.trim(),
      date: form.date.trim(),
      name,
      phone: form.phone.trim(),
      addr: form.addr.trim(),
      note: form.note.trim() || '-',
    }
    setOrders([...orders, o])
    // เก็บวันส่งไว้ให้กรอกต่อเร็วขึ้น (มักส่งวันเดียวกันหลายคน)
    setForm({ ...BLANK, date: form.date, qty: 1 })
    setPaste('')
    setFlash({ msg: '', ok: true })
  }

  const del = (i) => setOrders(orders.filter((_, idx) => idx !== i))
  const clearAll = () => {
    if (confirm('ล้างออเดอร์ทั้งหมด?')) setOrders([])
  }
  const loadDemo = () =>
    setOrders([
      { tiktok: '@ปาล์มที่ชอบไปเที่ยว', qty: 4, type: '', date: '15/09', name: 'วริศรา บุญนิยม', phone: '0617215185', addr: 'เลขที่ 30/13 ซอยสำเร็จพัฒนา13 ตำบลปลายบาง อำเภอบางกรวย จังหวัดนนทบุรี 1113', note: '401' },
      { tiktok: 'baifern_beauty', qty: 1, type: 'เหลี่ยมยาว', date: '15/09', name: 'ใบเฟิร์น สวยงาม', phone: '089-999-1111 / 086-222-3333', addr: '12 ม.5 ต.บางพูด อ.ปากเกร็ด จ.นนทบุรี 11120', note: 'กล่อง' },
    ])

  function printLabels() {
    if (orders.length === 0) {
      alert('ยังไม่มีออเดอร์ให้ปริ้นค่ะ 🐌')
      return
    }
    window.print()
  }

  const total = orders.reduce((s, o) => s + o.qty, 0)

  return (
    <>
      <header>
        <span className="snail">🐌</span>
        <div>
          <h1>Snail Rumruay Mai</h1>
          <p>ฟอร์มกรอกออเดอร์ — เล็บปลอม Handmade</p>
        </div>
      </header>

      <div className="wrap">
        {/* ===== FORM ===== */}
        <section className="card form-card no-print">
          <h2>➕ เพิ่มออเดอร์</h2>
          <p className="hint">วางข้อความจากแชทแล้วให้ระบบแยกให้ หรือกรอกเองก็ได้</p>

          <div className="paste-wrap">
            <label>🪄 วางข้อความจากแชท LINE</label>
            <textarea
              value={paste}
              onChange={(e) => setPaste(e.target.value)}
              placeholder="คัดลอกทั้งข้อความ (ทั้งส่วนสรุป + ที่อยู่) มาวางตรงนี้..."
            />
            <div className="paste-row">
              <button className="btn btn-primary" onClick={fillFromPaste}>🪄 แยกข้อมูลให้</button>
              <button className="btn btn-ghost" onClick={() => { setPaste(''); setFlash({ msg: '', ok: true }) }}>ล้างช่องวาง</button>
            </div>
            <p className="parsed-flash" style={{ color: flash.ok ? 'var(--ok)' : 'var(--pink-deep)' }}>{flash.msg}</p>
          </div>

          <div className="divider">แล้วเช็ก / แก้ไขได้ที่นี่</div>

          <div className="field">
            <label>ชื่อแอค TikTok</label>
            <input value={form.tiktok} onChange={set('tiktok')} placeholder="เช่น snail.nails" />
          </div>

          <div className="grid2">
            <div className="field">
              <label>จำนวน (ชุด)</label>
              <input type="number" min="1" value={form.qty} onChange={set('qty')} />
            </div>
            <div className="field">
              <label>วันส่ง</label>
              <input value={form.date} onChange={set('date')} placeholder="15/09" />
            </div>
          </div>

          <div className="field">
            <label>ประเภท</label>
            <input value={form.type} onChange={set('type')} placeholder="เช่น อัลมอนด์สั้น / เหลี่ยมยาว" />
          </div>

          <div className="field">
            <label>ชื่อจริง (ผู้รับ)</label>
            <input value={form.name} onChange={set('name')} placeholder="ชื่อ–นามสกุลผู้รับ" />
          </div>

          <div className="field">
            <label>เบอร์โทร</label>
            <input value={form.phone} onChange={set('phone')} placeholder="0xx-xxx-xxxx (หลายเบอร์คั่นด้วย /)" />
          </div>

          <div className="field">
            <label>ที่อยู่</label>
            <textarea value={form.addr} onChange={set('addr')} placeholder="บ้านเลขที่ ตำบล อำเภอ จังหวัด รหัสไปรษณีย์" />
          </div>

          <div className="field">
            <label>หมายเหตุ / ของแถม</label>
            <input
              value={form.note}
              onChange={set('note')}
              onKeyDown={(e) => { if (e.key === 'Enter') addOrder() }}
              placeholder="เช่น กล่อง, 401, ไพร์มเมอร์ (ไม่มีใส่ -)"
            />
          </div>

          <button className="btn btn-primary" onClick={addOrder}>🐌 เพิ่มลงตาราง</button>
          <p className="save-note">* ข้อมูลเก็บชั่วคราวในหน้านี้ (ต่อ Supabase เพื่อบันทึกถาวรได้)</p>
        </section>

        {/* ===== TABLE ===== */}
        <section className="card">
          <div className="list-head">
            <h2 style={{ margin: 0 }}>📋 ออเดอร์วันนี้ <span className="pill">{orders.length} ออเดอร์</span></h2>
            <div className="toolbar no-print">
              <button className="btn btn-ghost btn-sm" onClick={printLabels}>🖨️ ปริ้นใบปะหน้า</button>
              <button className="btn btn-ghost btn-sm" onClick={loadDemo}>✨ ใส่ตัวอย่าง</button>
              <button className="btn btn-ghost btn-sm" onClick={clearAll}>🗑️ ล้างทั้งหมด</button>
            </div>
          </div>

          {orders.length === 0 ? (
            <div className="empty">
              <div className="big">🐌</div>
              ยังไม่มีออเดอร์ — กรอกฟอร์มด้านซ้ายเพื่อเริ่ม
            </div>
          ) : (
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>ชื่อ TikTok</th><th>จำนวน</th><th>หมายเหตุ</th><th>วันส่ง</th>
                    <th>ชื่อจริง</th><th>ที่อยู่</th><th>เบอร์</th><th className="no-print"></th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((o, i) => (
                    <tr key={i}>
                      <td className="acc">{o.tiktok || '—'}</td>
                      <td className="qty">{o.qty}</td>
                      <td>{o.note && o.note !== '-' ? <span className="note-tag">{o.note}</span> : '-'}</td>
                      <td>{o.date || '—'}</td>
                      <td>{o.name || '—'}</td>
                      <td className="addr">{o.addr || '—'}</td>
                      <td>{o.phone || '—'}</td>
                      <td className="row-actions no-print">
                        <button className="icon-btn" title="ลบ" onClick={() => del(i)}>✕</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td>รวมทั้งหมด</td>
                    <td className="qty">{total}</td>
                    <td colSpan={6}>ชุด</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </section>
      </div>

      {/* ===== PRINT LABELS ===== */}
      <div className="print-area">
        {orders.map((o, i) => (
          <div className="label" key={i}>
            <div className="lbl-top">
              <span className="lbl-brand">🐌 Snail Rumruay Mai</span>
              <span>ส่ง: {o.date || '-'}</span>
            </div>
            <div className="lbl-sec">
              <div className="k">ผู้ส่ง</div>
              <div className="v">Snail Rumruay Mai (เล็บปลอม Handmade)</div>
            </div>
            <div className="lbl-sec">
              <div className="k">ผู้รับ</div>
              <div className="v"><b>{o.name || '-'}</b> &nbsp; โทร {o.phone || '-'}</div>
              <div className="v">{o.addr || '-'}</div>
            </div>
            <div className="lbl-items">
              <span>รายการ: {o.type || 'เล็บปลอม'} × {o.qty} ชุด</span>
              <span>{o.note && o.note !== '-' ? 'แถม: ' + o.note : ''}</span>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
